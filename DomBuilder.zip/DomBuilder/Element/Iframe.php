<?php
/** 
 * iframe – nested browsing context (inline frame).
 *
 * The iframe element introduces a new nested browsing context.
 *
 * @author    Sergey Baigudin, baigudin@mail.ru
 * @copyright 2012-2016 Sergey Baigudin
 * @license   http://baigudin.software/license/
 * @link      http://baigudin.software
 * @see       https://www.w3.org/TR/html-markup/iframe.html 
 */
namespace DomBuilder\Element; 

class Iframe extends \DomBuilder\ElementNode\TagDoubleBlock
{
  /** 
   * Constructor.
   */
  function __construct()
  {
    parent::__construct();
    $this->_tagName('iframe');
  }
}